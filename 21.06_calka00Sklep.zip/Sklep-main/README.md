# Sklep
Założenia: 
- wybieranie kategorii 
- wyświetlania przedmiotów  
- łączenie z bazą sql 
- dodawanie do koszyka 
- wyświetlanie łącznej wartości koszyka 
- możliwość stworzenia konta użytkownika / logowania

Wykorzystane technologie:
- C#
- HTML/CSS
- JavaScript
- ASP.NET
- SQL

![image](https://user-images.githubusercontent.com/92309948/232225703-3d003231-b397-4536-a2b9-16d1ec5bff4f.png)

![image](https://user-images.githubusercontent.com/92376466/232335856-34530228-61d9-40c3-b2da-cdff550462b0.png)
